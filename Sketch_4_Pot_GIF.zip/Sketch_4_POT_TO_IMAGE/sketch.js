/*
References for these codes:
https://itp.nyu.edu/physcomp/labs/labs-serial-communication/lab-serial-input-to-the-p5-js-ide/
https://itp.nyu.edu/physcomp/labs/labs-serial-communication/lab-serial-input-to-the-p5-js-ide/
*/

var serial;   // variable to hold an instance of the serialport library
var portName = '/dev/tty.usbmodem14201';    // fill in your serial port name here
var inData;   // variable to hold the input data from Arduino

const width = 400;
const height = 400;
let img1;
let img2;
let img3;
let img4;

function setup() {
  createCanvas(width,height);
  img1=loadImage('Layer1.png');
  img2=loadImage('Layer2.png');
  img3=loadImage('Layer3.png');
  img4=loadImage('Layer4.png');

  //set up communication port
  serial = new p5.SerialPort();       // make a new instance of the serialport library
  serial.on('list', printList);  // set a callback function for the serialport list event
  serial.on('connected', serverConnected); // callback for connecting to the server
  serial.on('open', portOpen);        // callback for the port opening
  serial.on('data', serialEvent);     // callback for when new data arrives
  serial.on('error', serialError);    // callback for errors
  serial.on('close', portClose);      // callback for the port closing

  serial.list();                      // list the serial ports
  serial.open(portName);              // open a serial port
}

function draw() {
  
  
  
  if(inData >0 && inData<99)
  {
  clear();
  imageMode(CENTER);
  image(img1,width/2,height/2);
  }
  if(inData >100 && inData<149)
  {
  clear();
  imageMode(CENTER);
  image(img2,width/2,height/2);
  }
  if(inData >150 && inData <254)
  {
  clear();
  imageMode(CENTER);
  image(img3,width/2,height/2);
  }
  else if(inData == 255)
  {
  clear();
  imageMode(CENTER);
  image(img4,width/2,height/2);
  }
}

// Following functions print the serial communication status to the console for debugging purposes

function printList(portList) {
 // portList is an array of serial port names
 for (var i = 0; i < portList.length; i++) {
 // Display the list the console:
 print(i + " " + portList[i]);
 }
}

function serverConnected() {
  print('connected to server.');
}

function portOpen() {
  print('the serial port opened.')
}

function serialEvent() {
  inData = Number(serial.read());
}

function serialError(err) {
  print('Something went wrong with the serial port. ' + err);
}

function portClose() {
  print('The serial port closed.');
}
